(() => {
  'use strict';

  // Muda a cada documento realmente carregado pelo navegador. Isso permite ao
  // service worker distinguir a nova página do estado intermediário em que um
  // <select> já mudou, mas o calendário ainda pertence ao mês anterior.
  globalThis.__carometroDocumentPageToken ||= `${performance.timeOrigin}:${crypto.randomUUID()}`;
  const PAGE_TOKEN = globalThis.__carometroDocumentPageToken;

  const FREQUENCY_PATH = '/FrequenciaAlunoEdicao.aspx';
  const DIARY_PATH = '/DiarioEscolarListagem.aspx';
  const SCHOOL_DAILY_PATH = '/FrequenciaDiaria.aspx';
  const GRADES_PATHS = ['/NotasModeloEdicao.aspx', '/NotasEdicao.aspx'];
  const MONTHS = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const byId = id => document.getElementById(id);
  const fieldValue = id => normalize(byId(id)?.value);
  const isFrequencyPage = () => location.pathname.toLowerCase() === FREQUENCY_PATH.toLowerCase();
  const isDiaryPage = () => location.pathname.toLowerCase() === DIARY_PATH.toLowerCase();
  const isSchoolDailyPage = () => location.pathname.toLowerCase() === SCHOOL_DAILY_PATH.toLowerCase();
  const isGradesPage = () => GRADES_PATHS.some(path => location.pathname.toLowerCase() === path.toLowerCase());

  function readContext() {
    return {
      year: fieldValue('cphFuncionalidade_cphCampos_txtAnoLetivo'),
      composition: fieldValue('cphFuncionalidade_cphCampos_txtComposicao'),
      subject: fieldValue('cphFuncionalidade_cphCampos_txtDisciplina'),
      grade: fieldValue('cphFuncionalidade_cphCampos_txtSerie'),
      shift: fieldValue('cphFuncionalidade_cphCampos_txtTurno'),
      className: fieldValue('cphFuncionalidade_cphCampos_txtTurma'),
      term: fieldValue('cphFuncionalidade_cphCampos_txtBimestre')
    };
  }

  const normalizedComparable = value => normalize(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const isFinalGradeHeading = value => {
    const heading = normalizedComparable(value);
    return /\b(?:media|nota|notas|resultado)\b/.test(heading) && /\b(?:final|finais)\b/.test(heading);
  };

  function contextMatches(request, context) {
    const fields = ['className', 'shift', 'subject', 'term'];
    return fields.every(field => !request[field] || normalizedComparable(context[field]).includes(normalizedComparable(request[field])));
  }

  function selectByText(id, wanted) {
    const select = byId(id);
    if (!select) throw new Error(`Filtro não encontrado: ${id}`);
    const expected = normalizedComparable(wanted);
    const option = [...select.options].find(item => {
      const label = normalizedComparable(item.textContent);
      return label === expected || label.includes(expected) || expected.includes(label);
    });
    if (!option) throw new Error(`O SIAP não ofereceu a opção "${wanted}".`);
    select.value = option.value;
    return normalize(option.textContent);
  }

  function selectedMonth(select) {
    return normalize(select?.selectedOptions?.[0]?.textContent || select?.value);
  }

  function isSavedAttendanceCell(cell) {
    return cell?.classList.contains('dialog') &&
      cell.classList.contains('letivo') &&
      normalizedComparable(cell.getAttribute('data-executado')) === 'true' &&
      normalizedComparable(cell.getAttribute('data-lancamento-frequencia')) === 'true';
  }

  function selectMonthOption(select, month) {
    const expected = normalizedComparable(month);
    const index = [...select.options].findIndex(option => normalizedComparable(option.textContent) === expected);
    if (index < 0) throw new Error(`O SIAP não ofereceu o mês "${month}".`);
    // As opções do SIAP não possuem atributo value e seu valor real inclui
    // a indentação do HTML. selectedIndex preserva esse valor e dispara o
    // controlador nativo do calendário; atribuir "Agosto" a value não o faz.
    select.selectedIndex = index;
    select.dispatchEvent(new Event('change', { bubbles:true }));
  }

  function diaryRows() {
    return [...document.querySelectorAll('#cphFuncionalidade_gdvListagem tr')].slice(1).map((row, index) => {
      const cells = [...row.cells].map(cell => normalize(cell.textContent));
      return {
        index,
        year:cells[0] || '',
        term:cells[2] || '',
        composition:cells[3] || '',
        grade:cells[4] || '',
        shift:cells[5] || '',
        subject:cells[6] || '',
        className:cells[7] || '',
        selected:/background-color\s*:\s*(?:#ffff99|rgb\(255,\s*255,\s*153\))/i.test(row.getAttribute('style') || '')
      };
    });
  }

  globalThis.__carometroDiarySnapshot = () => {
    if (!isDiaryPage()) throw new Error('O SIAP não está no Diário do Professor.');
    const optionTexts = id => [...(byId(id)?.options || [])].map(option => normalize(option.textContent));
    return {
      pageToken:PAGE_TOKEN,
      composition:normalize(byId('cphFuncionalidade_cphCampos_ddlComposicao')?.selectedOptions?.[0]?.textContent),
      grade:normalize(byId('cphFuncionalidade_cphCampos_ddlSerie')?.selectedOptions?.[0]?.textContent),
      term:normalize(byId('cphFuncionalidade_cphCampos_ddlBimestre')?.selectedOptions?.[0]?.textContent),
      shift:normalize(byId('cphFuncionalidade_cphCampos_ddlTurno')?.selectedOptions?.[0]?.textContent),
      subject:normalize(byId('cphFuncionalidade_cphCampos_ddlDisciplina')?.selectedOptions?.[0]?.textContent),
      compositions:optionTexts('cphFuncionalidade_cphCampos_ddlComposicao'),
      grades:optionTexts('cphFuncionalidade_cphCampos_ddlSerie'),
      rows:diaryRows()
    };
  };

  globalThis.__carometroSelectComposition = composition => {
    if (!isDiaryPage()) throw new Error('O SIAP não está no Diário do Professor.');
    const chosen = selectByText('cphFuncionalidade_cphCampos_ddlComposicao', composition);
    byId('cphFuncionalidade_cphCampos_ddlComposicao').dispatchEvent(new Event('change', { bubbles:true }));
    return chosen;
  };

  globalThis.__carometroListDiary = request => {
    if (!isDiaryPage()) throw new Error('O SIAP não está no Diário do Professor.');
    selectByText('cphFuncionalidade_cphCampos_ddlSerie', request.grade);
    selectByText('cphFuncionalidade_cphCampos_ddlBimestre', request.term);
    selectByText('cphFuncionalidade_cphCampos_ddlTurno', request.shift);
    selectByText('cphFuncionalidade_cphCampos_ddlDisciplina', request.subject);
    byId('cphFuncionalidade_btnListar').click();
    return true;
  };

  globalThis.__carometroSelectDiaryRow = className => {
    const expected = normalizedComparable(className);
    const rows = diaryRows();
    const match = rows.find(row => normalizedComparable(row.className) === expected);
    if (!match) throw new Error(`A turma "${className}" não apareceu na listagem do SIAP.`);
    document.querySelectorAll('#cphFuncionalidade_gdvListagem tr')[match.index + 1].click();
    return true;
  };

  globalThis.__carometroOpenFrequency = () => {
    if (!diaryRows().some(row => row.selected)) throw new Error('O SIAP não confirmou a seleção da turma.');
    byId('cphFuncionalidade_btnAuxiliar2').click();
    return true;
  };

  function readVisibleAttendance(target) {
    const studentNames = new Map(
      [...document.querySelectorAll('.listaDeAlunos .item[data-matricula], .listaAlunos .item[data-matricula]')]
        .map(item => [normalize(item.dataset.matricula), normalize(item.dataset.nome || item.textContent).replace(/^\d+\.\s*/, '')])
        .filter(([registration]) => registration)
    );
    document.querySelectorAll('.listaDeFrequencias').forEach(list => {
      const date = normalize(list.dataset.data);
      const lesson = normalize(list.dataset.numeroaula) || '1';
      list.querySelectorAll('.item[data-matricula]').forEach(item => {
        const registration = normalize(item.dataset.matricula);
        if (!registration) return;
        const name = studentNames.get(registration) || `Matrícula final ${registration.slice(-4)}`;
        const key = `${date}|${lesson}|${registration}`;
        target.set(key, {
          date, lesson, registration, name,
          absent:String(item.dataset.ausente).toLowerCase() === 'true',
          blocked:String(item.dataset.bloqueado).toLowerCase() === 'true',
          situation:normalize(item.dataset.situacao)
        });
      });
    });
  }

  globalThis.__carometroAttendanceSnapshot = request => {
    if (!isFrequencyPage()) throw new Error('Abra no SIAP a página Frequência da turma escolhida.');
    const context = readContext();
    if (!contextMatches(request || {}, context)) throw new Error('A turma aberta no SIAP não corresponde à seleção do Carômetro.');
    const select = byId('selectMesCalendarioMensal');
    if (!select) throw new Error('O seletor de meses do SIAP não foi encontrado.');
    const calendar = byId('cphFuncionalidade_cphCampos_CalendarioMensal');
    const selectedDate = fieldValue('cphFuncionalidade_cphCampos_txtDataSelecionada');
    const month = selectedMonth(select);
    const registeredDays = [...new Set([...(calendar?.querySelectorAll('td') || [])]
      .filter(isSavedAttendanceCell)
      .map(cell => Number.parseInt(normalize(cell.textContent), 10))
      .filter(day => Number.isInteger(day)))]
      .sort((a, b) => a - b);
    const entries = new Map();
    readVisibleAttendance(entries);
    return {
      pageToken:PAGE_TOKEN,
      context,
      month,
      monthNumber:MONTHS.indexOf(month) + 1,
      registeredDays,
      selectedDate,
      entries:[...entries.values()]
    };
  };

  globalThis.__carometroAttendancePosition = request => {
    if (!isFrequencyPage()) throw new Error('Abra no SIAP a página Frequência da turma escolhida.');
    const context = readContext();
    if (!contextMatches(request || {}, context)) throw new Error('A turma aberta no SIAP não corresponde à seleção do Carômetro.');
    const select = byId('selectMesCalendarioMensal');
    return {
      pageToken:PAGE_TOKEN,
      month:selectedMonth(select),
      selectedDate:fieldValue('cphFuncionalidade_cphCampos_txtDataSelecionada')
    };
  };

  globalThis.__carometroPageToken = () => PAGE_TOKEN;

  globalThis.__carometroSelectMonth = month => {
    if (!MONTHS.includes(month)) throw new Error(`Mês inválido: ${month}`);
    const select = byId('selectMesCalendarioMensal');
    if (!select) throw new Error('O seletor de meses do SIAP não foi encontrado.');
    selectMonthOption(select, month);
    return true;
  };

  globalThis.__carometroSelectRegisteredDay = day => {
    const calendar = byId('cphFuncionalidade_cphCampos_CalendarioMensal');
    const cell = [...(calendar?.querySelectorAll('td') || [])].filter(isSavedAttendanceCell).find(candidate =>
      Number.parseInt(normalize(candidate.textContent), 10) === day
    );
    if (!cell) throw new Error(`A chamada verde do dia ${day} não foi encontrada.`);
    cell.click();
    return true;
  };

  // Leitor isolado da Frequência Diária usada pela Secretaria. Ele compartilha
  // apenas a ponte da extensão; os seletores e a navegação do Diário do
  // Professor acima permanecem independentes.
  const cleanStudentName = value => normalize(value)
    .replace(/^\d+\s*(?:[.\-)–—:]\s*)?/, '')
    .replace(/\s*(?:[.\-(–—:]\s*)?\d+\s*\)?$/, '')
    .trim();

  const normalizedStudentName = value => cleanStudentName(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

  const detailValue = label => {
    const title = [...document.querySelectorAll('.tituloDetalhes')]
      .find(item => normalizedComparable(item.textContent) === normalizedComparable(label));
    return normalize(title?.parentElement?.querySelector('.conteudoDetalhes')?.textContent);
  };

  const selectedSchoolDailyDate = () => normalize(byId('h3TituloFuncionalidade')?.textContent).match(/\b\d{2}\/\d{2}\/\d{4}\b/)?.[0] || '';

  function schoolDailyClassStatus(card) {
    if (card.classList.contains('dentroPrazo')) return 'filled_on_time';
    if (card.classList.contains('foraPrazo')) return 'filled_late';
    if (card.classList.contains('diaNaoLetivo')) return 'non_school_day';
    if (card.classList.contains('existeExcecao')) return 'exception';
    return 'not_filled';
  }

  function schoolDailyClasses() {
    return [...document.querySelectorAll('.containerTurmaTurno')].flatMap(container => {
      const shift = normalize(container.querySelector('.tituloTurno')?.textContent);
      return [...container.querySelectorAll('.listaTurmas[data-codigoturma]')].map(card => {
        const text = normalize(card.textContent);
        const match = text.match(/^(.*?)\s*\(([^)]+)\)\s*$/);
        return {
          code:normalize(card.dataset.codigoturma),
          className:normalize(match?.[1] || text),
          compositionCode:normalize(match?.[2]),
          shift,
          status:schoolDailyClassStatus(card)
        };
      });
    });
  }

  function schoolDailyContext() {
    if (!document.querySelector('.listaDeAlunos .item[data-matricula]')) return null;
    const composition = detailValue('Composição');
    const grade = detailValue('Série');
    const className = detailValue('Turma');
    const compositionCode = composition.match(/^\s*(\d+)/)?.[1] || '';
    const cards = schoolDailyClasses();
    const card = cards.find(item =>
      normalizedComparable(item.className) === normalizedComparable(className) &&
      (!compositionCode || item.compositionCode === compositionCode)
    );
    const periodText = normalize(document.querySelector('#FormularioPrincipal')?.textContent);
    const period = periodText.match(/Ano base\/Semestre:\s*(\d{4})\s*\/\s*([12])/i);
    const selectedDate = selectedSchoolDailyDate();
    return {
      year:period?.[1] || selectedDate.slice(-4),
      term:period?.[2] ? `${period[2]}º semestre` : '',
      composition,
      compositionCode,
      grade,
      className,
      shift:card?.shift || '',
      classCode:card?.code || '',
      classStatus:card?.status || '',
      subject:'Frequência diária da escola'
    };
  }

  function schoolDailyEntries() {
    const namesByRegistration = new Map(
      [...document.querySelectorAll('.listaDeAlunos .item[data-matricula]')]
        .map(item => {
          const registration = normalize(item.dataset.matricula);
          const name = cleanStudentName(item.dataset.nome || item.querySelector('.aluno')?.textContent || item.textContent);
          return [registration, name];
        })
        .filter(([registration, name]) => registration && normalizedStudentName(name))
    );
    const normalizedNameCounts = new Map();
    namesByRegistration.forEach(name => {
      const key = normalizedStudentName(name);
      normalizedNameCounts.set(key, (normalizedNameCounts.get(key) || 0) + 1);
    });
    const date = selectedSchoolDailyDate();
    const entries = [];
    document.querySelectorAll('.listaDeFrequencias .item[data-matricula]').forEach(item => {
      const name = namesByRegistration.get(normalize(item.dataset.matricula));
      if (!name) return;
      entries.push({
        date,
        name,
        absent:String(item.dataset.ausente).toLowerCase() === 'true',
        blocked:String(item.dataset.bloqueado).toLowerCase() === 'true',
        situation:normalize(item.dataset.situacao),
        duplicateName:normalizedNameCounts.get(normalizedStudentName(name)) > 1
      });
    });
    return entries;
  }

  globalThis.__carometroSchoolDailyNormalizeName = normalizedStudentName;

  globalThis.__carometroSchoolDailySnapshot = () => {
    if (!isSchoolDailyPage()) throw new Error('Abra no SIAP a página Frequência diária.');
    return {
      pageToken:PAGE_TOKEN,
      selectedDate:selectedSchoolDailyDate(),
      classes:schoolDailyClasses(),
      context:schoolDailyContext(),
      entries:schoolDailyEntries()
    };
  };

  globalThis.__carometroSchoolDailySelectDate = date => {
    if (!isSchoolDailyPage()) throw new Error('Abra no SIAP a página Frequência diária.');
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(String(date || ''))) throw new Error('Data inválida para leitura.');
    const control = byId('controleData') || byId('controleDataPreSelecao');
    if (!control) throw new Error('O controle de data do SIAP não foi encontrado.');
    control.setAttribute('onclick', `__doPostBack('ctl00$cphFuncionalidade$ControleFrequencia','${date}')`);
    control.click();
    return true;
  };

  globalThis.__carometroSchoolDailyOpenClass = classCode => {
    if (!isSchoolDailyPage()) throw new Error('Abra no SIAP a página Frequência diária.');
    const code = normalize(classCode);
    if (!/^\d+$/.test(code)) throw new Error('Código de turma inválido.');
    const card = [...document.querySelectorAll('.listaTurmas[data-codigoturma]')]
      .find(item => normalize(item.dataset.codigoturma) === code);
    if (!card) throw new Error('A turma escolhida não apareceu nesta data.');
    const status = schoolDailyClassStatus(card);
    if (!['filled_on_time', 'filled_late'].includes(status)) throw new Error('A frequência desta turma não está preenchida nesta data.');
    card.click();
    return true;
  };

  function readClassicGradeEntries() {
    const tables = [...document.querySelectorAll('table')];
    const candidates = tables.map(table => {
      const rows = [...table.rows];
      const headerIndex = rows.findIndex(row => {
        const labels = [...row.cells].map(cell => normalizedComparable(cell.textContent));
        return labels.includes('alunos') && isFinalGradeHeading(labels.at(-1));
      });
      if (headerIndex < 0) return null;
      const header = rows[headerIndex];
      const labels = [...header.cells].map(cell => normalizedComparable(cell.textContent));
      return { rows, headerIndex, studentIndex:labels.indexOf('alunos'), finalIndex:labels.length - 1 };
    }).filter(Boolean);
    if (candidates.length !== 1) throw new Error('A tabela de Notas Finais do SIAP não foi identificada com segurança.');
    const { rows, headerIndex, studentIndex, finalIndex } = candidates[0];
    const entries = [];
    for (const row of rows.slice(headerIndex + 1)) {
      const cells = [...row.cells];
      const nameText = normalize(cells[studentIndex]?.textContent);
      if (!/^\d+\.\s*\S/.test(nameText)) continue;
      if (cells.length <= finalIndex) throw new Error('A linha do aluno não contém a coluna Notas Finais.');
      const name = nameText.replace(/^\d+\.\s*/, '').trim();
      if (normalizedStudentName(name).split(' ').length < 2) throw new Error('O SIAP exibiu um nome de aluno em formato desconhecido.');
      const raw = normalize(cells[finalIndex].textContent);
      if (raw && raw !== '--' && !/^\d{1,2}(?:[,.]\d)?$/.test(raw))
        throw new Error('O SIAP exibiu uma nota final em formato desconhecido.');
      const score = !raw || raw === '--' ? null : Number(raw.replace(',', '.'));
      if (score !== null && (score < 0 || score > 10)) throw new Error('O SIAP exibiu uma nota fora da escala de 0 a 10.');
      entries.push({ registration:'', name, score, blocked:false, situation:'' });
    }
    if (!entries.length) throw new Error('A tabela de Notas Finais ainda não contém alunos legíveis.');
    return entries;
  }

  // A posição determina a nota: somente a última coluna de totais é lida.
  // O título deve indicar nota/média final, ainda que varie entre telas do SIAP.
  globalThis.__carometroGradesSnapshot = () => {
    if (!isGradesPage()) throw new Error('Abra no SIAP a tela Notas da turma e disciplina desejadas.');
    const context = readContext();
    const required = ['year', 'className', 'shift', 'subject', 'term'];
    if (required.some(key => !context[key])) throw new Error('O contexto das notas ainda não terminou de carregar.');
    if (location.pathname.toLowerCase() === '/notasedicao.aspx')
      return { pageToken:PAGE_TOKEN, schoolName:normalize(byId('lblNomeEntidade')?.textContent), context, entries:readClassicGradeEntries() };
    const students = [...document.querySelectorAll('.listaDeAlunos .itens > .item[data-matricula]')];
    const totalLists = [...document.querySelectorAll('.listaDeTotais.totalDeNotas')];
    const finalList = totalLists.at(-1);
    if (!isFinalGradeHeading(finalList?.querySelector('.cabecalho .titulo')?.textContent))
      throw new Error('A última coluna do SIAP não identifica uma média ou nota final. Nenhuma nota foi lida.');
    const cells = [...(finalList?.querySelectorAll('.itens > .item[data-matricula]') || [])];
    if (!students.length || students.length !== cells.length) throw new Error('A lista de alunos e a coluna final não estão completas.');
    const seen = new Set();
    const entries = students.map((student, index) => {
      const cell = cells[index];
      const registration = normalize(student.dataset.matricula);
      if (!registration || seen.has(registration) || registration !== normalize(cell.dataset.matricula))
        throw new Error('A ordem das notas não corresponde à lista de alunos.');
      seen.add(registration);
      const raw = normalize(cell.textContent);
      if (raw && !/^\d{1,2}[,.]\d$/.test(raw)) throw new Error('O SIAP exibiu uma nota final em formato desconhecido.');
      const score = raw ? Number(raw.replace(',', '.')) : null;
      if (score !== null && (score < 0 || score > 10)) throw new Error('O SIAP exibiu uma nota fora da escala de 0 a 10.');
      return {
        registration,
        name:normalize(student.dataset.nome || student.textContent).replace(/^\d+\.\s*/, ''),
        score,
        blocked:String(cell.dataset.bloqueado).toLowerCase() === 'true',
        situation:normalize(student.dataset.descricaosituacao)
      };
    });
    return { pageToken:PAGE_TOKEN, schoolName:normalize(byId('lblNomeEntidade')?.textContent), context, entries };
  };

  // Leitor independente da coluna Faltas. Não depende de notas lançadas e
  // não altera o comportamento da captura de médias finais.
  globalThis.__carometroAbsencesSnapshot = () => {
    if (!isGradesPage()) throw new Error('Abra no SIAP a aba Notas da turma e disciplina desejadas.');
    const context=readContext();
    if (['year','className','shift','subject','term'].some(key=>!context[key]))
      throw new Error('O contexto das notas ainda não terminou de carregar.');
    const readHours = (label,required) => {
      const suffix=label==='Carga Horária Ministrada'?'CargaHorariaMinistrada':'CargaHorariaPrevista';
      const direct=[...document.querySelectorAll('input')].filter(input=>
        [input.id,input.name].some(value=>String(value||'').toLowerCase().includes(suffix.toLowerCase())));
      const labels=[...document.querySelectorAll('label,span,div')].filter(node=>
        normalizedComparable(node.textContent)===normalizedComparable(label)&&
        ![...node.children].some(child=>normalizedComparable(child.textContent)===normalizedComparable(label)));
      const labelNode=labels.length===1?labels[0]:null;
      const next=labelNode?.nextElementSibling;
      const matching=direct.length===1?direct[0]:labelNode?
        (labelNode.control||byId(labelNode.htmlFor)||labelNode.parentElement?.querySelector('input')||
          (next?.matches?.('input')?next:next?.querySelector?.('input'))):null;
      const raw=normalize(matching?.value);
      if(!raw){if(required)throw new Error(`${label} não foi encontrada na tela de Notas.`);return null;}
      if(!/^\d{1,4}$/.test(raw))throw new Error(`${label} está em formato desconhecido.`);
      return Number(raw);
    };
    const taughtHours=readHours('Carga Horária Ministrada',false);
    const plannedHours=readHours('Carga Horária Prevista',false);
    let entries;
    if (location.pathname.toLowerCase()==='/notasedicao.aspx') {
      const candidates=[...document.querySelectorAll('table')].map(table=>{
        const rows=[...table.rows];
        const headerIndex=rows.findIndex(row=>{
          const labels=[...row.cells].map(cell=>normalizedComparable(cell.textContent));
          return labels.includes('alunos')&&labels.includes('faltas')&&isFinalGradeHeading(labels.at(-1));
        });
        if(headerIndex<0)return null;
        const labels=[...rows[headerIndex].cells].map(cell=>normalizedComparable(cell.textContent));
        return {rows,headerIndex,studentIndex:labels.indexOf('alunos'),absenceIndex:labels.indexOf('faltas')};
      }).filter(Boolean);
      if(candidates.length!==1)throw new Error('A coluna Faltas não foi identificada com segurança nesta tela.');
      const {rows,headerIndex,studentIndex,absenceIndex}=candidates[0];
      entries=rows.slice(headerIndex+1).flatMap(row=>{
        const cells=[...row.cells];
        const nameText=normalize(cells[studentIndex]?.textContent);
        if(!/^\d+\.\s*\S/.test(nameText))return [];
        if(cells.length<=absenceIndex)throw new Error('A linha do aluno não contém a coluna Faltas.');
        const raw=normalize(cells[absenceIndex].textContent);
        if(raw&&!/^\d{1,4}$/.test(raw))throw new Error('O SIAP exibiu faltas em formato desconhecido.');
        return [{registration:'',name:nameText.replace(/^\d+\.\s*/,''),absences:raw?Number(raw):null,blocked:false}];
      });
    } else {
      const students=[...document.querySelectorAll('.listaDeAlunos .itens > .item[data-matricula]')];
      const lists=[...document.querySelectorAll('.listaDeTotais')]
        .filter(list=>normalizedComparable(list.querySelector('.cabecalho .titulo')?.textContent)==='faltas');
      if(lists.length!==1)throw new Error('A coluna Faltas não foi identificada com segurança nesta tela.');
      const cells=[...lists[0].querySelectorAll('.itens > .item[data-matricula]')];
      if(!students.length||students.length!==cells.length)
        throw new Error('A lista de alunos e a coluna Faltas não estão completas.');
      const seen=new Set();
      entries=students.map((student,index)=>{
        const cell=cells[index];
        const registration=normalize(student.dataset.matricula);
        if(!registration||seen.has(registration)||registration!==normalize(cell.dataset.matricula))
          throw new Error('A ordem das faltas não corresponde à lista de alunos.');
        seen.add(registration);
        const raw=normalize(cell.textContent);
        if(raw&&!/^\d{1,4}$/.test(raw))throw new Error('O SIAP exibiu faltas em formato desconhecido.');
        return {registration,name:normalize(student.dataset.nome||student.textContent).replace(/^\d+\.\s*/,''),
          absences:raw?Number(raw):null,blocked:String(cell.dataset.bloqueado).toLowerCase()==='true'};
      });
    }
    if(!entries.length)throw new Error('A coluna Faltas não contém alunos legíveis.');
    return {pageToken:PAGE_TOKEN,schoolName:normalize(byId('lblNomeEntidade')?.textContent),context,
      taughtHours,plannedHours,entries};
  };
})();
